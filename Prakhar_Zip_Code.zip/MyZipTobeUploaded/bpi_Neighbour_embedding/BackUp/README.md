Results for 'BPI'12 (W)' dataset
